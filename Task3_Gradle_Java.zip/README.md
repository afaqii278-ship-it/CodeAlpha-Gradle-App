# Task 3: Java Application using Gradle

## Steps
1. Install Java + Gradle
2. Create project:
   gradle init
3. Build project:
   gradle build
4. Run project:
   gradle run

## CI/CD Integration
- Use Jenkins or GitHub Actions
- Automate build & test

## Outcome
- Automated builds
- Dependency management
